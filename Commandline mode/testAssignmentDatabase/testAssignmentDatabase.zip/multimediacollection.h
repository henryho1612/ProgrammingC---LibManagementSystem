#include "ICollection.h"
#include <list>

using namespace std;


class MultimediaCollection : public ICollection {
	
public:
	list<Collection> collections;
	MultimediaCollection();
	~MultimediaCollection();

	void showCollections();
	void addCollection(Collection col);

	void loadDatabase();
	void saveDatabase();
	void enterCollection();
};

