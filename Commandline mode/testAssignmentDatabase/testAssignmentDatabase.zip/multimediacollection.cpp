#include "multimediacollection.h"
#include <iostream>
#include <cstdlib>
#include "cppconn/driver.h"
#include "cppconn/exception.h"
#include "cppconn/resultset.h"
#include "cppconn/statement.h"
#include "cppconn/prepared_statement.h"

#pragma comment(lib, "mysqlcppconn.lib")

using namespace std;

MultimediaCollection::MultimediaCollection() {}

MultimediaCollection::~MultimediaCollection() {collections.clear(); cout << collections.size() << "\n";}


void MultimediaCollection::showCollections()
{
	It it = collections.begin();
	while(it != collections.end()) {
		cout << it->getCid() << "\t";
		cout << it->getType() << "\t";
		cout << it->getDataType() << "\t";
		cout << it->getTitle() << "\t";
		cout << it->getVersion() << "\t";
		cout << it->getPublisher() << "\t";
		cout << it->getYear() << "\t";
		cout << it->getDuration() << "\t";
		cout << it->getCate() << "\n";
		*it++;
	}
}

void MultimediaCollection::addCollection(Collection c)
{
	collections.push_back(c);
	//cout << "Add new collection successfully!\n";
}

void MultimediaCollection::enterCollection()
{	
	string sInput;
	int iInput;
	cout << "Enter Collection Process\n";
	cout << "=============================\n";
	Collection col;
	cout << "Collection ID: ";
	cin >> sInput;
	col.setCid(sInput);
	cout << "Collection Type: ";
	cin >> sInput;
	col.setType(sInput);
	cout << "Collection Data Type: ";
	cin >> sInput;
	col.setDataType(sInput);
	cout << "Collection Title: ";
	cin >> sInput;
	col.setTitle(sInput);
	cout << "Collection Version: ";
	cin >> sInput;
	col.setVersion(sInput);
	cout << "Collection Publisher: ";
	cin >> sInput;
	col.setPublisher(sInput);
	cout << "Collection Year: ";
	cin >> sInput;
	col.setYear(sInput);
	cout << "Collection Category: ";
	cin >> sInput;
	col.setCate(sInput);
	cout << "Collection Duration: ";
	cin >> iInput;
	col.setDuration(iInput);
	cout << "\nEnter new collection completed!\n";
	addCollection(col);
}

void MultimediaCollection::loadDatabase()
{
	try {
		sql::Driver *driver;
		sql::Connection *con;
		sql::ResultSet *resultSet;
		sql::PreparedStatement *prepareStmt;

		driver = get_driver_instance();
		con = driver->connect("tcp://127.0.0.1:3306", "root", "dhis");
		con->setSchema("tutorial");

		prepareStmt = con->prepareStatement("SELECT * FROM multimedia");
		resultSet = prepareStmt->executeQuery();
		while(resultSet->next()) {
			collections.push_back(Collection(resultSet->getString("id"),
									 resultSet->getString("type"),
									 resultSet->getString("datatype"),
									 resultSet->getString("title"),
									 resultSet->getString("version"),
									 resultSet->getString("publisher"),
									 resultSet->getString("year"),
									 resultSet->getInt("duration"),
									 resultSet->getString("category")));
		}

		delete resultSet;
		delete prepareStmt;
		delete con;

	} catch (sql::SQLException &e) {
	  cout << "# ERR: SQLException in " << __FILE__;
	  cout << "(" << __FUNCTION__ << ") on line " << __LINE__ << endl;
	  cout << "# ERR: " << e.what();
	  cout << " (MySQL error code: " << e.getErrorCode();
	  cout << ", SQLState: " << e.getSQLState() << " )" << endl;
	}
}

void MultimediaCollection::saveDatabase()
{	/*
	try {
		sql::Driver *driver;
		sql::Connection *con;
		sql::Statement *statement;
		sql::PreparedStatement *preparedStmt;
		
		driver = get_driver_instance();
		con = driver->connect("tcp://127.0.0.1:3306", "root", "dhis");
		con->setSchema("tutorial");
		
		It it = collections.begin();
		while(it != collections.end()) {
			
			*it++;
		}

		delete statement;
		delete con;
		
	} catch (sql::SQLException &e) {
	  cout << "# ERR: SQLException in " << __FILE__;
	  cout << "(" << __FUNCTION__ << ") on line " << __LINE__ << endl;
	  cout << "# ERR: " << e.what();
	  cout << " (MySQL error code: " << e.getErrorCode();
	  cout << ", SQLState: " << e.getSQLState() << " )" << endl;
	}
	*/
}
