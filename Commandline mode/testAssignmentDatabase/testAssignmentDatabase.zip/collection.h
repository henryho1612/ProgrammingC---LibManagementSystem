#include <string>
#include <list>
using namespace std;

class Collection {

	string cId, cType, cDataType, cTitle, cVersion, cPublisher, cYear, cCate;
	int cDuration;
	string status;
	string barcode;

public:	
	Collection();
	Collection(string, string, string, string, string, string, string, int, string);
	~Collection();

	void setCid(string id);
	void setType(string type);
	void setDataType(string datatype);
	void setTitle(string title);
	void setVersion(string version);
	void setPublisher(string publisher);
	void setYear(string year);
	void setCate(string cate);
	void setDuration(int dur);
	void setStatus(string status);
	void setBarcode(string barcode);
	string getCid();
	string getType();
	string getDataType();
	string getTitle();
	string getVersion();
	string getPublisher();
	string getYear();
	string getCate();
	int getDuration();
	string getStatus();
	string getBarcode();
};
typedef list<Collection> collections;
typedef collections::iterator It;