#include <iostream>
#include "collection.h"
using namespace std;

class ICollection {
public:
	virtual ~ICollection() {cout << "ICollection is deleted!\n";};
	virtual void addCollection(Collection col) = 0;
	virtual void showCollections() = 0;
};