#include "multimediacollection.h"

int main()
{	
	MultimediaCollection mulCollection;
	mulCollection.loadDatabase();
	//mulCollection.showCollections();
	//mulCollection.enterCollection();
	//mulCollection.saveDatabase();
	mulCollection.showCollections();
	system("pause");

	return 0;
}